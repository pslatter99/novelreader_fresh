package com.example.novelreader_fresh

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
