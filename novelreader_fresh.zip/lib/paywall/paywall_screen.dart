import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'access.dart';

class PaywallScreen extends StatelessWidget {
  final String bookKey;
  const PaywallScreen({super.key, required this.bookKey});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Unlock access')),
      body: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 420),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text(
                'Continue reading with:',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900),
              ),
              const SizedBox(height: 16),

              // Subscribe button
              ElevatedButton(
                onPressed: () async {
                  await AccessManager.instance.chooseSubscribe();
                  if (context.mounted) Navigator.pop(context, true);
                },
                child: const Text('Subscribe — all books + early releases'),
              ),
              const SizedBox(height: 8),

              // Ads button
              OutlinedButton(
                onPressed: () async {
                  await AccessManager.instance.chooseAds(bookKey);
                  if (context.mounted) Navigator.pop(context, true);
                },
                child: const Text('Read for free with ads'),
              ),
              const SizedBox(height: 8),

              // Purchase button
              TextButton(
                onPressed: () async {
                  await AccessManager.instance.choosePurchase(bookKey);
                  if (context.mounted) Navigator.pop(context, true);
                },
                child: const Text('Purchase eBook'),
              ),

              if (kDebugMode) ...[
                const SizedBox(height: 24),
                TextButton(
                  onPressed: () => Navigator.pop(context, true),
                  child: const Text('DEBUG: bypass paywall'),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}
