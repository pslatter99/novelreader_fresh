// lib/paywall/access.dart
import 'package:flutter/foundation.dart' show kDebugMode;
import 'package:shared_preferences/shared_preferences.dart';

class AccessManager {
  // ---------- singleton ----------
  AccessManager._();
  static final AccessManager instance = AccessManager._();

  // ---------- prefs / keys ----------
  SharedPreferences? _prefs;

  static const _kSubscribed   = 'access.subscribed';
  static const _kPurchased    = 'access.purchased_books';    // StringList of book keys
  static const _kAdsBooks     = 'access.ads_books';          // StringList of book keys that opted for ads
  static const _kGateChapter  = 5;                           // paywall at chapter 5+

  // progress keys: progress.<bookKey>.chapter / .page
  String _kProgChapter(String bookKey) => 'progress.$bookKey.chapter';
  String _kProgPage(String bookKey)    => 'progress.$bookKey.page';

  // ---------- state ----------
  bool _subscribed = false;
  final Set<String> _purchasedBooks = <String>{};
  final Set<String> _adsBooks = <String>{};

  // Dev bypass (still respects prod behavior when false)
  bool debugPassThrough = kDebugMode;

  Future<void> init() async {
    _prefs = await SharedPreferences.getInstance();
    _subscribed = _prefs?.getBool(_kSubscribed) ?? false;
    _purchasedBooks
      ..clear()
      ..addAll(_prefs?.getStringList(_kPurchased) ?? const []);
    _adsBooks
      ..clear()
      ..addAll(_prefs?.getStringList(_kAdsBooks) ?? const []);
  }

  // ---------- gating ----------
  bool canAccessChapter(String bookKey, int chapterNumber) {
    if (debugPassThrough) return true;               // dev bypass (optional)
    if (_subscribed) return true;                    // all books unlocked
    if (_purchasedBooks.contains(bookKey)) return true; // this book unlocked
    if (_adsBooks.contains(bookKey)) return true;    // opted to read with ads (demo unlock)
    return chapterNumber < _kGateChapter;            // free chapters before gate
  }

  // ---------- choices from paywall ----------
  Future<void> chooseSubscribe() async {
    _subscribed = true;
    await _prefs?.setBool(_kSubscribed, true);
  }

  Future<void> chooseAds(String bookKey) async {
    _adsBooks.add(bookKey);
    await _prefs?.setStringList(_kAdsBooks, _adsBooks.toList());
  }

  Future<void> choosePurchase(String bookKey) async {
    _purchasedBooks.add(bookKey);
    await _prefs?.setStringList(_kPurchased, _purchasedBooks.toList());
  }

  // ---------- progress ----------
  Future<void> saveProgress(String bookKey, {required int chapter, required int page}) async {
    await _prefs?.setInt(_kProgChapter(bookKey), chapter);
    await _prefs?.setInt(_kProgPage(bookKey), page);
  }

  int getSavedChapter(String bookKey) => _prefs?.getInt(_kProgChapter(bookKey)) ?? 1;
  int getSavedPage(String bookKey)    => _prefs?.getInt(_kProgPage(bookKey)) ?? 0;

  // ---------- small helpers ----------
  bool get isSubscribed => _subscribed;
  bool get hasAnyAdsBooks => _adsBooks.isNotEmpty;
}
